#' Title of your function
#' 
#' @description A short description of what your function does.
#' @param arg1 Description of the first argument.
#' @param arg2 Description of the second argument.
#' @return Description of what the function returns.
#' @export
#'
#' 
function1 <- function(arg1, arg2) {
    # Your function code
    print(arg1)
    print(arg2)
}
